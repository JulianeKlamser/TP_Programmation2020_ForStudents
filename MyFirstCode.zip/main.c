#include <stdio.h>

int main() {
   // printf() displays the string inside quotation
   printf("Hello, ESPCI! I am learning C. For a new line I need to type this\n :) \n");
   return 0;
}
